package com.tweetapp.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.tweetapp.model.Like;


@Repository
public interface LikeRepo extends JpaRepository<Like,Integer> {

	@SuppressWarnings("unchecked")
	Like save(Like like);
	List<Like> findByTweetId(String tweetId);

}

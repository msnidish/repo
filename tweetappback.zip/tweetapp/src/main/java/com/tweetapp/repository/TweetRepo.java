package com.tweetapp.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.tweetapp.model.Tweet;

@Repository
public interface TweetRepo extends JpaRepository<Tweet,String>{

	Tweet findByTid (int tid);
     List<Tweet> findAll();
	List<Tweet> findByLoginId(String loginId);

	void deleteByTid(int Tid);

	@Transactional
	void deleteByLoginIdAndTid(String loginId, int id);

	@Modifying
	@Query("update Tweet t set t.tweet=:tweet where t.loginId=:loginId and t.tid=:tid")
	@Transactional
	void updateTweet(@Param("loginId") String loginId,@Param("tweet") String tweet,@Param("tid") int tid);
}

package com.tweetapp.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.tweetapp.model.Login;

@Repository
public interface LoginRepo extends JpaRepository<Login, String>{

	//@Query(value="select * from login where loginId=?0 ", nativeQuery=true)
	public Login findByLoginId(String loginId);
	
	@Modifying
	@Query(value="insert into login(login_id,password) values(:loginId,:password)",nativeQuery = true)
	@Transactional
	public void addDetails(@Param("loginId") String loginId,@Param("password") String password);
	
	@Modifying
	@Query("update Login l set l.password=:password where l.loginId=:loginId")
	@Transactional
	void updatePassword(@Param("loginId") String loginId,@Param("password") String newPassword);
}

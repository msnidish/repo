package com.tweetapp.model;

import javax.persistence.*;
import javax.persistence.Id;

@Entity
public class Tweet {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int tid;
	private String loginId;
	private String tweet;
	public String getLoginId() {
		return loginId;
	}
	public int getTid() {
		return tid;
	}
	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}
	public String getTweet() {
		return tweet;
	}
	public void setTweet(String tweet) {
		this.tweet = tweet;
	}
	public Tweet(String loginId, String tweet) {
		super();
		this.loginId = loginId;
		this.tweet = tweet;
	}
	public Tweet() {
		super();
	}
	@Override
	public String toString() {
		return "Tweet [loginId=" + loginId + ", tweet=" + tweet + "]";
	}
	

}

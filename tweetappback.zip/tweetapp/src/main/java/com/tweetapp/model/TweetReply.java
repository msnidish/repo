package com.tweetapp.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="tweet_reply")
public class TweetReply {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int tid;
	@Column(name="tweet_id")
	private int tweetId;
	@Column(name="user_id")
	private String userId;
	@Column(name="reply_time")
	private String replyTime;
	@Column(name="reply_text")
	private String replyText;
	private String tags;
	public int getTweetId() {
		return tweetId;
	}
	public void setTweetId(int tweetId) {
		this.tweetId = tweetId;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getReplyTime() {
		return replyTime;
	}
	public void setReplyTime(String replyTime) {
		this.replyTime = replyTime;
	}
	public String getReplyText() {
		return replyText;
	}
	public void setReplyText(String replyText) {
		this.replyText = replyText;
	}
	public String getTags() {
		return tags;
	}
	public void setTags(String tags) {
		this.tags = tags;
	}
	public TweetReply(int tweetId, String userId, String replyTime, String replyText, String tags) {
		super();
		this.tweetId = tweetId;
		this.userId = userId;
		this.replyTime = replyTime;
		this.replyText = replyText;
		this.tags = tags;
	}
	public TweetReply() {
		super();
	}
	
	
}

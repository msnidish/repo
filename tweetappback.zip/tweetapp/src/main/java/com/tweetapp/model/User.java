package com.tweetapp.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class User {
	
	private String fname;
	private String lname;
	@Id
	private String email;
	@Column(name="login_id")
	private String loginId;
	private String password;
	private String contactnumber;
	public String getLoginId() {
		return loginId;
	}
	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getContactnumber() {
		return contactnumber;
	}
	public void setContactnumber(String contactnumber) {
		this.contactnumber = contactnumber;
	}
	public User(String fname, String lname, String email,String loginId, String password, String contactnumber) {
		super();
		this.fname = fname;
		this.lname = lname;
		this.email = email;
		this.loginId=loginId;
		
		this.password = password;
        this.contactnumber=contactnumber;
	}
	public User() {
		super();
	}
	@Override
	public String toString() {
		return "User [fname=" + fname + ", lname=" + lname + ", email=" + email + ", LoginId=" + loginId + ", password=" + password + ", contactnumber=" + contactnumber + "]";
	}
	
	
	

}

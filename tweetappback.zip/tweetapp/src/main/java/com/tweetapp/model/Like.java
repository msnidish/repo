package com.tweetapp.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="tweetlike")
public class Like {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	@Column(name="tweet_id")
	private int tweetId;
	@Column(name="liked_by")
	private String likedBy;
	public int getTweetId() {
		return tweetId;
	}
	public void setTweetId(int tweetId) {
		this.tweetId = tweetId;
	}
	public String getLikedBy() {
		return likedBy;
	}
	public void setLikedBy(String likedBy) {
		this.likedBy = likedBy;
	}
	public Like(int tweetId, String likedBy) {
		super();
		this.tweetId = tweetId;
		this.likedBy = likedBy;
	}
	public Like() {
		super();
	}
	@Override
	public String toString() {
		return "Like [tweetId=" + tweetId + ", likedBy=" + likedBy + "]";
	}
	
	
}

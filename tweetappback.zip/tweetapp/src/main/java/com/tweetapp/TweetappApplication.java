package com.tweetapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
//@EnableJpaRepositories(basePackageClasses=UsersRepo.class)
public class TweetappApplication {
	public static void main(String[] args)  {
	SpringApplication.run(TweetappApplication.class, args);
	}
//	static Scanner sc =new Scanner(System.in);
//	static boolean isUserLogged=false;
//	private static UserServiceImpl userService = new UserServiceImpl();
//	private static TweetServiceImpl tweetService = new TweetServiceImpl();
//	private static UserRepo userRepository=new UserRepo();
//	private static String username;
//
//	public static void main(String[] args) throws SQLException {
//		//SpringApplication.run(TweetappApplication.class, args);
//		Scanner sc=new Scanner(System.in);
//		int ch;
//		while(true)
//		{
//			if(!isUserLogged)
//			{
//				System.out.println("1.Register \n2.Login \n3.Forgot Password");
//				ch=sc.nextInt();
//				switch(ch)
//				{
//				case 1:
//					//register();
//					System.out.println(register());
//					break;
//				case 2:
//					login();
//					break;
//				case 3:
//					forgotPassword();
//					break;
//				default:
//					System.out.println("Choose the correct option");
//				}
//			}else {
//				System.out.println(
//						"1.Post a tweet\n2.View your tweets\n3.View all users\n4.View all users and thier Tweets\n5.Change Password\n6.Logout");
//				ch = sc.nextInt();
//				switch (ch) {
//				case 1:
//					System.out.println(postATweet(username));
//					break;
//				case 2:
//					List<String> tweets = viewTweetByUser(username);
//					if (tweets.size() !=0)
//						tweets.forEach(System.out::println);
//					else
//						System.out.println("No tweets Found");
//					break;
//
//				case 3:
//					List<String> users = viewAllUsers();
//					if (users != null)
//						users.forEach(System.out::println);
//					else
//						System.out.println("Sorry!! No users Found.");
//					break;
//				case 4:
//					Map<String, List<String>> userTweet = viewAllUserTweet();
//					for (String key : userTweet.keySet()) {
//						System.out.println(key + "'s Tweets are: ");
//						userTweet.get(key).forEach(System.out::println);
//						System.out.println();
//					}
//					break;
//				case 5:
//					resetPassword(username);
//					break;
//				case 6:
//					isUserLogged = logout();
//					System.exit(0);
//				default:
//					System.out.println("**Please choose correct option**");
//				}
//			}
//		}
//		
//		
//	}
//
//	private static String postATweet(String email) {
//		// TODO Auto-generated method stub
//		Tweet tweet = new Tweet();
//		tweet.setEmail(email);
//		System.out.println("Enter your tweet:");
//		tweet.setTweet(sc.nextLine());
//		return tweetService.postATweet(tweet);
//	}
//
//	private static String register() throws SQLException {
//		System.out.println("Register in Main");
//		Scanner sc=new Scanner(System.in);
//		User user = new User();
//		System.out.println("Enter your First Name:");
//		String fname = sc.nextLine();
//		if (fname.matches("[A-Za-z]{3,15}$"))
//			user.setFname(fname);
//		else {
//			System.out.println("Invalid first name!! Please enter a proper name between 3 to 15 characters");
//			return "sorry!! Registration Failed.";
//		}
//		System.out.println("Enter your Last Name:");
//		String lastName = sc.nextLine();
//		if (lastName.matches("[A-Za-z]{3,15}$"))
//			user.setLname(lastName);
//		else {
//			System.out.println("Invalid last name!! Please enter a proper name between 3 to 15 characters");
//			return "sorry!! Registration Failed.";
//		}
//		System.out.println("Enter Your Gender:");
//		String gender = sc.nextLine();
//		if (gender.equalsIgnoreCase("male") || gender.equalsIgnoreCase("female") || gender.equalsIgnoreCase("others")) {
//			user.setGender(gender);
//		} else {
//			System.out.println("Invalid Gender!! Please enter Male, Female or Others");
//			return "sorry!! Registration Failed.";
//		}
////		System.out.println("Enter Your Phone Number");
////		long number=sc.nextLong();
////		String reg="[789][0-9]{9}"; 
////		if(String.valueOf(number).matches(reg))
////			user.setNumber(number);
////		else {
////			System.out.println("Invalid Phone Number!! Please enter a valid number.");
////			return "sorry!! Registration Failed.";
////		}
//		
//		System.out.println("Enter your Date of Birth in year-month-day format:"); 
//		String dob = sc.next();
//		//SimpleDateFormat sdf=new SimpleDateFormat("dd//MM//yyyy");
//		try {
//			user.setDob(Date.valueOf(dob));
//		} catch (Exception e) {
//			System.out.println("**Invalid Date Format**");
//			return "sorry!! Registration Failed.";
//		}
//		
//		System.out.println("Enter User Name");
//		String username = sc.next();
//		String regex = "^(?=.{1,64}@)[A-Za-z0-9_-]+(\\.[A-Za-z0-9_-]+)*@[^-][A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)*(\\.[A-Za-z]{2,})$";
//		if (Pattern.compile(regex).matcher(username).matches()) {
//			user.setEmail(username);
//		} else {
//			System.out.println("Invalid Email!! Please enter proper email address as username.");
//			return "sorry!! Registration Failed.";
//		}
//		System.out.println("Enter Password");
//		String pass = sc.next();
//		if (pass.length() < 8 || pass.length() > 20) {
//			System.out.println(
//					"Invalid Password!! Password must be more or equal to 8 characters and less than 20 characters");
//			return "sorry!! Registration Failed.";
//		}
//		user.setPassword(pass);
//		System.out.println(user);
//		return userService.register(user);
//	}
//
//	public static boolean login() {
//		Scanner sc=new Scanner(System.in);
//		System.out.println("In Login Method");
//		System.out.println("Enter User Name");
//		String userName = sc.nextLine();
//		System.out.println("Enter Password");
//		String password = sc.nextLine();
//		if (userName == null || password == null || userName.trim().isEmpty() || password.trim().isEmpty()) {
//			System.out.println("Login unsuccessful --> User name or password is empty");
//			return false;
//		} else {
//			if (userRepository.findByEmail(userName)!=null) {
//			username = userName;
//			isUserLogged=true;
//			return userService.login(username, password);
//			}
//			return false;
//		}
//	}
//	
//	public static boolean forgotPassword() {
//		Scanner sc=new Scanner(System.in);
//		System.out.println("In Forgot Password Method");
//		System.out.println("Enter the UserName");
//		username=sc.next();
//		System.out.println(userRepository.findByEmail(username));
//		if(userRepository.findByEmail(username)!=null)
//		{
//			System.out.println("Enter Your new Password");
//			String enteredpass=sc.next();
//			if (enteredpass.length() < 8 || enteredpass.length() > 20) {
//				System.out.println(
//						"Invalid Password!! Password must be more or equal to 8 characters and less than 20 characters");
//				return false;
//			}
//			System.out.println("Re-Enter Your Password");
//			String newpass=sc.next();
//			if (newpass.length() < 8 || newpass.length() > 20) {
//				System.out.println(
//						"Invalid Password!! Password must be more or equal to 8 characters and less than 20 characters");
//			}
//			userService.forgotPassword(username, enteredpass, newpass);
//			return true;
//			
//		}
//		return false;
//		
//	}
//	
//	public static List<String> viewAllUsers() {
//		try {
//			return userService.viewAllUsers();
//		} catch (Exception ex) {
//			System.out.println(ex.getMessage());
//			return null;
//		}
//	}
//
//	public static List<String> viewTweetByUser(String email) {
//		try {
//			return tweetService.viewTweetByUser(email);
//		} catch (Exception ex) {
//			System.out.println(ex.getMessage());
//			return null;
//		}
//	}
//
//	private static Map<String, List<String>> viewAllUserTweet() {
//		return tweetService.viewTweetByAllUser();
//	}
//	
//	public static void resetPassword(String username) {
//		try {
//			System.out.println("Enter your old password");
//			String oldPassword = sc.nextLine();
//			if(!userService.isPasswordMatch(username, oldPassword))
//				return;
//			System.out.println("Enter your new password");
//			String newPassword = sc.nextLine();
//			if (newPassword.length() < 8 || newPassword.length() > 20) {
//				System.out.println("Password should be between 8 to 20 characters");
//				return;
//			}
//			System.out.println("Confirm your new password");
//			String newCheckPassword = sc.nextLine();
//			if (!newPassword.equals(newCheckPassword)) {
//				throw new TweetAppExceptionHandler("**New Password and Confirm Password should be the same**");
//			}
//			if (newPassword.equals(oldPassword)) {
//				throw new TweetAppExceptionHandler("**Old password and New password should not be the same**");
//			}
//			if (userService.resetPassword(username, oldPassword, newPassword)) {
//				System.out.println("Your password has been changed successfully!!");
//				return;
//			}
//			System.out.println("Sorry!! Failed to change Password.");
//			return ;
//		} catch (Exception ex) {
//			System.out.println(ex.getMessage());
//			return ;
//		}
//	}
//
//
//	public static boolean logout() {
//		if (userService.logout(username)) {
//			System.out.println("You've Logged out Successfully!!");
//			return false;
//		}
//		System.out.println("Sorry!! Failed to logout.");
//		return true;
//	}
}

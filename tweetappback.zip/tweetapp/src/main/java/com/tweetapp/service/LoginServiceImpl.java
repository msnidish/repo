package com.tweetapp.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tweetapp.model.Login;
import com.tweetapp.repository.LoginRepo;

@Service
public class LoginServiceImpl {

	@Autowired
	LoginRepo loginRepo;

	/**
	 * Overriding method to load the user details from database with user name
	 * 
	 * @param userName
	 * @return This returns the user name and password
	 */
	//@Override
	public Login loadLoginByLoginId(String username) {
		System.out.println("loadLoginByLoginId in LoginServiceImpl");
		System.out.println(username);
		Login log = loginRepo.findByLoginId(username);
		
		System.out.println(log);
		//return new Login(log.getLoginId(), log.getPassword());
		return log;
	}
}

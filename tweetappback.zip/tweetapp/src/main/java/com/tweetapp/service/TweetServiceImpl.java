package com.tweetapp.service;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tweetapp.controller.AuthController;
import com.tweetapp.model.Like;
import com.tweetapp.model.Tweet;
import com.tweetapp.model.TweetReply;
import com.tweetapp.repository.LikeRepo;
import com.tweetapp.repository.ReplyTweetRepo;
import com.tweetapp.repository.TweetRepo;

@Service
public class TweetServiceImpl implements TweetService{

	@Autowired
	TweetRepo tweetRepo;
	@Autowired
	LikeRepo likeRepo;
	@Autowired
	ReplyTweetRepo replyTweetRepo;
	
	@Override
	public Tweet postATweet(Tweet tweet) {
		// TODO Auto-generated method stub
		return tweetRepo.save(tweet);
	}

	@Override
	public List<Tweet> viewTweetByUser(String loginId) {
		System.out.println("finding tweet"+loginId);
		return tweetRepo.findByLoginId(loginId);
	}

	@Override
	public List<Tweet> viewTweetByAllUser() {
		// TODO Auto-generated method stub
		System.out.println("getting all tweets");
		return tweetRepo.findAll();
	}

	@Override
	public void updateTweet(String loginId, String tweet, int id) {
		// TODO Auto-generated method stub
		 tweetRepo.updateTweet(loginId, tweet, id);
	}

	@Override
	public List<Tweet> deleteTweet(String loginId, int id) {
		// TODO Auto-generated method stub
		 tweetRepo.deleteByLoginIdAndTid(loginId,id);
		 return tweetRepo.findAll();
	}

	@Override
	public Like likeTweet(Like like) {
		System.out.println("liking "+like.getTweetId());
		return likeRepo.save(like);
	}

	@Override
	public List<Like> getAllLikes() {
		// TODO Auto-generated method stub
		return likeRepo.findAll();
	}

	@Override
	public TweetReply postReply(TweetReply tweetReply) {
		// TODO Auto-generated method stub
		return replyTweetRepo.save(tweetReply);
	}

	@Override
	public Map<String, List<String>> getAllReply() {
		// TODO Auto-generated method stub
		return replyTweetRepo.findAll().stream().collect(Collectors.groupingBy(TweetReply::getUserId,
		Collectors.mapping(TweetReply::getReplyText, Collectors.toList())));
	}
	
//	TweetRepo tweetRepo=new TweetRepo();
//
//	@Override
//	public String postATweet(Tweet tweet) {
//		System.out.println("Post a tweet in tweetServiceImpl");
//		// TODO Auto-generated method stub
//		try {
//			tweetRepo.postTweet(tweet);
//			return "Tweet Added";
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//			return "";
//		}
//	}
//
//	@Override
//	public List<String> viewTweetByUser(String loginId) {
//		// TODO Auto-generated method stub
//		System.out.println("viewTweetByUser in tweetServiceImpl");
//		System.out.println("Getting your tweet....");
//		//System.out.println(tweetRepo.findAll());
//		System.out.println(tweetRepo.findAll().stream().filter(tweet -> tweet.getLoginId().equals(loginId))
//				.map(Tweet::getTweet).collect(Collectors.toList()));
//		return tweetRepo.findAll().stream().filter(tweet -> tweet.getLoginId().equals(loginId))
//				.map(Tweet::getTweet).collect(Collectors.toList());
//	}
//
//	@Override
//	public Map<String, List<String>> viewTweetByAllUser() {
//		System.out.println("viewTweetByAllUser in TweetServiceImpl");
//		// TODO Auto-generated method stub
//		System.out.println("Getting All Users Based On Tweet");
//		return tweetRepo.findAll().stream().collect(Collectors.groupingBy(Tweet::getLoginId,
//				Collectors.mapping(Tweet::getTweet, Collectors.toList())));
//	}
//
//	@Override
//	public String updateTweet(String loginId,String tweet, int id) {
//		// TODO Auto-generated method stub
//		boolean check=tweetRepo.updateTweet(loginId,tweet,id);
//		System.out.println(check);
//		 //if(tweetRepo.updateTweet(loginId,tweet,id)) {
//			 System.out.println("inside tweetserviceImpl if condition");
//			 tweetRepo.updateTweet(loginId,tweet,id);
//			 return "Tweet Updated Successfully!!";
//		 //}
////		 else
////			 return "Updated Unsuccessful!!";
//	}
//
//	@Override
//	public String deleteTweet(String loginId, int id) {
//		tweetRepo.deleteTweet(loginId, id);
//		return "Tweet deleted successfully";
//	}
//
//	@Override
//	public String likeTweet(Like like) {
//		// TODO Auto-generated method stub
//		tweetRepo.postLike(like);
//		return "Like added successfully";
//	}
//
//	@Override
//	public List<Like> getAllLikes() {
//		// TODO Auto-generated method stub
//		return tweetRepo.getAllLikes();
//	}
//
//	@Override
//	public String postReply(TweetReply tweetReply) {
//		// TODO Auto-generated method stub
//		tweetRepo.postTweetReply(tweetReply);
//			return "Reply added successfully";
////		else
////			return "unsuccessful";
//	}
//
//	@Override
//	public Map<String, List<String>> getAllReply() {
//		// TODO Auto-generated method stub
//		return tweetRepo.getAllReply().stream().collect(Collectors.groupingBy(TweetReply::getUserId,
//				Collectors.mapping(TweetReply::getReplyText, Collectors.toList())));
//	}
//	
	
	

	
}

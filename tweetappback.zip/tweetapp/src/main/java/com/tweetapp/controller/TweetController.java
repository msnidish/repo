package com.tweetapp.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sun.org.apache.bcel.internal.generic.RETURN;
import com.tweetapp.exception.TweetAppExceptionHandler;
import com.tweetapp.model.Like;
import com.tweetapp.model.Tweet;
import com.tweetapp.model.TweetReply;
import com.tweetapp.repository.TweetRepo;
import com.tweetapp.service.TweetServiceImpl;

@CrossOrigin(origins= "http://localhost:3000")
@RestController
@RequestMapping("/api/v1.0/tweets")
public class TweetController {

	@Autowired
	TweetServiceImpl tweetServiceImpl;
	
	@Autowired
	AuthController authController;
	
//	public Producer producer;
//	
//	@Autowired
//	public TweetController(Producer producer) {
//		super();
//		this.producer = producer;
//	}
//	
	@Autowired
	TweetRepo tweetRepo;
	
//	@GetMapping("/publish")
//	public String sendMessage(@PathVariable String message) {
//		this.producer.sendMessage(message);
//		return "Connection established";
//	}
	@GetMapping("/all")
	public List<Tweet> getAllTweets() throws TweetAppExceptionHandler {
		
			return tweetServiceImpl.viewTweetByAllUser();
	
	}
	
	@GetMapping("/{username}")
	public List<Tweet> getTweetByUser(@PathVariable String username) throws TweetAppExceptionHandler {
		
			return tweetServiceImpl.viewTweetByUser(username);
		
	}
	
	@PostMapping("/{username}/add")
	public Tweet addPost(@PathVariable String username,@RequestBody Tweet tweet) throws TweetAppExceptionHandler {
		
			if(username.equalsIgnoreCase(tweet.getLoginId())) {
				return tweetServiceImpl.postATweet(tweet);
			}
			else
			{
				return null;
			}
		
	}
	
	@PutMapping("/{username}/update/{id}")
	public void updateTweet( @PathVariable String username,@PathVariable int id,@RequestBody Tweet tweet) throws TweetAppExceptionHandler {
		
		if(username.equalsIgnoreCase(tweet.getLoginId())) {
			System.out.println("Inside update tweet if");
			 tweetServiceImpl.updateTweet(tweet.getLoginId(), tweet.getTweet(), id);
		}
	}
	
	@DeleteMapping("/{username}/delete/{id}")
	public List<Tweet> deleteTweet(@PathVariable String username,@PathVariable int id) throws TweetAppExceptionHandler {
		 
			return tweetServiceImpl.deleteTweet(username, id);
		
	}
	
	@PostMapping("/addLike")
	public Like addLike( @RequestBody Like like) throws TweetAppExceptionHandler {
		    System.out.println("liking");
			return tweetServiceImpl.likeTweet(like);
		
	}
	
	@GetMapping("/getLikes")
	public List<Like> getAllLikes() throws TweetAppExceptionHandler{
	
			return tweetServiceImpl.getAllLikes();
		
	}
	
	@PostMapping("/reply")
	public TweetReply postTweetReply(@RequestBody TweetReply tweetReply) throws TweetAppExceptionHandler {
	         System.out.println("posting reply");
			return tweetServiceImpl.postReply(tweetReply);
		
	}
	
	@GetMapping("/getreply")
	public Map<String, List<String>> getAllReplies() throws TweetAppExceptionHandler{
		
			return tweetServiceImpl.getAllReply();
		
	}
}

package com.tweetapp.controller;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.tweetapp.exception.TweetAppExceptionHandler;
import com.tweetapp.model.Login;
import com.tweetapp.model.User;
import com.tweetapp.repository.LoginRepo;
import com.tweetapp.repository.UsersRepo;
import com.tweetapp.service.UserServiceImpl;
@CrossOrigin(origins="http://localhost:3000")
@RestController
public class UserController {

	@Autowired
	UserServiceImpl userServiceImpl;
	@Autowired
	UsersRepo userRepo;
	@Autowired
	LoginRepo loginRepo;
	@Autowired
	AuthController authController;
	
	@PostMapping("/api/v1.0/tweets/register")
	public String registerUser( @RequestBody User user) throws SQLException {
		System.out.println("controller start");
		loginRepo.addDetails(user.getLoginId(),user.getPassword());
		userServiceImpl.register(user);
		return "User registration is successful!!";
	}
	
	@PostMapping("/api/v1.0/tweets/{username}/forgot")
	public String forgotPassword( @PathVariable String username,@RequestBody Login login) {
		User u=userRepo.findByLoginId(username);
		if(u!=null) {
			loginRepo.updatePassword(username, login.getPassword());
			userServiceImpl.forgotPassword(username, login.getPassword());
			return "Password Updated successfully";
		}
		else
		{
			return null;
		}
	}
	
	@GetMapping("/api/v1.0/tweets/users/all")
	public List<User> getAllUsers() throws TweetAppExceptionHandler {
	     System.out.println("allusers");
		return userServiceImpl.viewAllUsers();
		
		
	}
	
	@GetMapping("/api/v/1.0/tweets/user/search/{username}")
	public User getUser(@PathVariable String username) throws TweetAppExceptionHandler {
		
		return userServiceImpl.findUser(username);
		
	}
}
